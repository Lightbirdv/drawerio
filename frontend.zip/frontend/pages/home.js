export default function Home(){
    return <h1>LandingPage</h1>
    
}